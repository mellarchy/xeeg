# Xeeg - Template File Generator

An advanced and universal template file generator that puts you in charge

The documentation for this project is available at https://mellarchy.github.io/xeeg
